var Cryptr = require('cryptr');
var express = require("express");
const SendOtp = require('sendotp');
const sendOtp = new SendOtp('242588AkKEro0an0P5bc18f95');

var connection = require('./../config');
cryptr = new Cryptr('myTotalySecretKey');

module.exports.register = function (req, res) {
  var authkey = "242588AkKEro0an0P5bc18f95";
  var senderid = "TESTAP";
  var otpNumber = Math.floor(1000 + Math.random() * 9000);
  var encryptedString = cryptr.encrypt(req.body.password);
  var users = {
    name: req.body.name,
    phone: req.body.phone,
    address: req.body.address,
    email: req.body.email,
    password: encryptedString,
    otp: otpNumber,
    loginstatus: 0,
    active: 0
  }

  if (users.name.length > 0 && users.phone.length > 0) {
    var phoneNumber = "91" + users.phone;
   // For MySql database
    connection.query("INSERT INTO members set ?", users, function (error, response, fields) {
      if (error) {
        console.error(error);
        res.json({
          status: false,
          message: 'there are some error with query'
        })
      } else {
        res.json({
          status: true,
          //sdata:results,
          message: 'OTP sent to the user and also Stored sucessfully'
        })
      }
    });
    sendOtp.send(phoneNumber, senderid, otpNumber, function (error, data) {
      if (data) {
        console.log("otp is sent to your number");
      } else {
        console.log("otp sending failed");

      }
    });
  } else {
    console.log("not able to register");
    res.json({
      status: false,
      message: 'User not able to register'
    });
  }
}
