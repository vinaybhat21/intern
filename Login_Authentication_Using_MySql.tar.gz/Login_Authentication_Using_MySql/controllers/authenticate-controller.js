var Cryptr = require('cryptr');
cryptr = new Cryptr('myTotalySecretKey');

var connection = require('./../config');
module.exports.authenticate = function (req, res) {
    console.log("inside authenticate function");
    var name = req.body.name;
    var password = req.body.password;
    var loginstatus = 0;
    if (name.length > 0 && password.length > 0) {
        connection.query('SELECT * FROM members WHERE name = ?', [name], function (error, results, fields) {
            if (error) {
                res.json({
                    status: false,
                    message: 'there are some error with query'
                })
            } else {
                if (results.length > 0) {
                    decryptedString = cryptr.decrypt(results[results.length - 1].password);
                    var loginstatus = results[results.length - 1].loginstatus;
                    if (password == decryptedString) {
                        if (loginstatus == 0){
                            connection.query("UPDATE members SET loginstatus = 1 where name = ?", name, function (error, results, fields) {
                                if (error) {
                                  console.error(error);
                                  res.json({
                                    status: false,
                                    message: 'there are some error in query execution'
                                  })
                                } else {
                                    res.json({
                                        status: true,
                                        message: "User successfully authenticated"
                                    })
                                }
                            });

                        } else {
                            res.json({
                                status: true,
                                message: "User already logged in from another device"
                            })
                        }
                    } else {
                        res.json({
                            status: false,
                            message: "password does not match"
                        });
                    }

                }
                else {
                    res.json({
                        status: false,
                        message: "Name does not exits"
                    });
                }
            }
        });
    } else {
        res.json({
            status: false,
            message: "Please enter proper user details"
        });
    }
}
