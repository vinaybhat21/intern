var express = require("express");
var bodyParser = require('body-parser');
var connection = require('./config');

path = require('path');
var app = express();


var authenticateController = require('./controllers/authenticate-controller');
var registerController = require('./controllers/register-controller');
var forgotController = require('./controllers/forgot-controller');
var otpController = require('./controllers/otpVerify-controller');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', function (req, res) {
    res.sendFile(__dirname + "/Public/");
})

/* route to handle login , registration and forgot password */
app.post('/api/register', registerController.register);
app.post('/api/otp', otpController.verifyOtp);
app.post('/api/authenticate', authenticateController.authenticate);
app.post('/api/forgot', forgotController.forgot);

console.log(authenticateController);
app.post('/controllers/register-controller', registerController.register);
app.post('/controllers/otp-controller', otpController.verifyOtp);
app.post('/controllers/authenticate-controller', authenticateController.authenticate);
app.post('/controllers/forgot-controller', forgotController.forgot);
app.listen(3000);
console.log('server running now on port no: 3000');
