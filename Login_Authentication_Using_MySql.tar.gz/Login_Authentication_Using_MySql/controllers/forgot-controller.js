var msg91 = require('msg91-sms');
var Cryptr = require('cryptr');
var express = require("express");
var connection = require('./../config');
var authkey = '';

//for single number
var number = '';

//Sender ID
var senderid = '';

//message
var message = '';

//Route
var route = '';

//Country dial code
var dialcode = '';



cryptr = new Cryptr('myTotalySecretKey');

module.exports.forgot = function (req, res) {
    var password = req.body.password;
    var phone = req.body.phone;
    if (phone.length > 0) {
        connection.query('SELECT * FROM members WHERE phone = ?', [phone], function (error, results, fields) {
            if (error) {
                res.json({
                    status: false,
                    message: 'There are some error in query execution'
                })
            } else {
                if (results.length > 0) {
                    console.log("Password sent");
                    res.json({
                        status: true,
                        message: "Reset Password Sent to your mobile number"
                    });
                    //varibale to hold the password after decryption
                    decryptedString = cryptr.decrypt(results[results.length - 1].password);

                    if (decryptedString) {
                        // authorization key from msg91
                        authkey = "242588AkKEro0an0P5bc18f95";

                        //for single number
                        number = phone;

                        //Sender ID
                        senderid = "TESTAP";

                        //message
                        message = "Received message for forgot passsword for " + senderid + " and the password is: " + decryptedString;

                        //Route
                        route = "4";

                        //Country dial code
                        dialcode = "91";
                        // sends the text message 

                        msg91.sendOne(authkey, number, message, senderid, route, dialcode, function (response) {
                            //Returns Message ID, If Sent Successfully or the appropriate Error Message 
                            console.log(response);
                        });

                    } else {
                        res.json({
                            status: false,
                            message: "password does not match"
                        });
                    }
                } else {
                    console.log("Password does not sent");
                    res.json({
                        status: false,
                        message: "phone number does not exits"
                    });

                }
            }
        });
    } else {
        res.json({
            status: false,
            message: "please enter phone number to continue"
        });
    }
}