var Cryptr = require('cryptr');
const SendOtp = require('sendotp');
const sendOtp = new SendOtp('242588AkKEro0an0P5bc18f95');
var connection = require('./../config');
cryptr = new Cryptr('myTotalySecretKey');
var userReg = require('./register-controller')
var otpNumber;
module.exports.verifyOtp = function (req, res) {
  var encryptedString = cryptr.encrypt(req.body.password);
  var users = {
    name: req.body.name,
    phone: req.body.phone,
    password: encryptedString,
    otp: req.body.pin
  }
  if (users.otp.length > 0) {
        // For MySql database..........
      connection.query("SELECT otp FROM members where phone = ?", [users.phone], function (error, results, fields) {
        if (results.length > 0) {
          otpNumber = results[results.length - 1].otp;
          if (users.otp == otpNumber) {
            connection.query("UPDATE members SET active = 1 where otp = ?", [users.otp], function (error, results, fields) {
              if (error) {
                console.error(error);
                res.json({
                  status: false,
                  message: 'there are some error in query execution'
                })
              } else {
                res.json({
                  status: true,
                  message: 'user registered sucessfully'
                })
                console.log("user registered successfully");
              }
            });
          } else {
            res.json({
              status: false,
              message: 'Please enter the proper entries'
            })
          }
        } else {
          res.json({
            status: false,
            message: 'Query execution Failed!!'
          })
        }
      });
    } else {
    res.json({
      status: false,
      message: 'Please enter the Otp'
    })
  }
}